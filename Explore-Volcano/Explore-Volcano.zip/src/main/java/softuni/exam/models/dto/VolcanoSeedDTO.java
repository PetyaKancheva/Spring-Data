package softuni.exam.models.dto;

import com.google.gson.annotations.Expose;
import lombok.Getter;
import lombok.Setter;
import softuni.exam.models.entity.Country;
import softuni.exam.models.enums.VolcanoType;


@Getter
@Setter
public class VolcanoSeedDTO {
    @Expose

    private String name;
    @Expose
    private Integer elevation;
    @Expose
    private VolcanoType volcanoType;
    @Expose
    private boolean isActive;
    @Expose
    private String lastEruption;
    @Expose
    private long country;




}
